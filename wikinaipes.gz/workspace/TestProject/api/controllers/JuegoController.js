/**
 * JuegoController
 *
 * @description :: Server-side logic for managing Juegoes
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
    
	'nuevo': function (req, res){
	    res.view();
	},
	
	crear: function (req, res, next){
		Juego.create(req.params.all(), function (err, Juego){
			if(err) return next(err);
			res.redirect('/juego/mostrar/'+Juego.id);
		});
	},
	
	mostrar: function (req, res, next){
		Juego.findOne({id: req.params['id']})
    		.exec(function foundUser(err, Juego){
        	if(err) return next(err);
        	if(!Juego) return next();
        	res.view({
            	Juego: Juego
        	});
    	});
	},
	
	index: function (req, res, next){
		Juego.find(function foundJuegos (err, Juegos) {
        	if(err) return next(err);
        	res.view({
            	Juegos: Juegos
        	});
		});
	},
	
	editar: function(req, res, next){
		Juego.findOne({id: req.params['id']})
    		.exec(function foundUser(err, Juego){
        	if(err) return next(err);
        	if(!Juego) return next();
        	res.view({
            	Juego: Juego
        	});
    	});
	},
	
	actualizar: function (req, res, next){
		Juego.update(req.param('id'), req.params.all(), function JuegoEditado (err) {
			if (err) {
				return res.redirect('/juego/editar/'+ req.param('id'));
			}
			
			res.redirect('/juego/mostrar/'+ req.param('id'));
		});
	},
	
	borrar: function(req, res, next){
		Juego.findOne(req.param('id'), function JuegoEncontrado (err) {
			if (err) return next(err);
		if(!Juego) return next("ese Juego no existe!");
		Juego.destroy(req.param('id'), function JuegoDestruido (err) {
			if (err) return next(err);
		});
		
			res.redirect('/juego');
		});
	}
};
