/**
* Juego.js
*
* @description :: TODO: You might write a short summary of how this model works and what it represents here.
* @docs        :: http://sailsjs.org/#!documentation/models
*/

module.exports = {
  
  autoUpdatedAt: true,
  schema: true,

  attributes: {
    Nombre: {
      type: 'string',
      unique: true,
      required: true
    },
    Creador: {
      type: 'string',
    },
    numMinJugadores: 'integer',
    numMaxJugadores: 'integer',
    tiempoPromedioJuego: 'integer',
    Publico: 'boolean',
    Descripcion: 'text',
  }
};

